from django.contrib import admin
from home.models import Contect, Singup, Detail

# Register your models here.

admin.site.register(Contect)
admin.site.register(Singup)
admin.site.register(Detail)

