from django.db import models
from django.contrib.auth.models import User

# Create your models here.
class Contect(models.Model):
    name = models.CharField(max_length=122)
    email = models.CharField(max_length=80)
    mobile = models.CharField(max_length=14)
    desc = models.TextField()
    date = models.DateField()

    def __str__(self):
        return self.name



class Singup(models.Model):
    usernaam = models.CharField(max_length=122)
    email = models.CharField(max_length=122)
    password = models.CharField(max_length=122)
    password1=models.CharField(max_length=122)

    def __str__(self):
        return self.usernaam

class Login(models.Model):
    l_username = models.CharField(max_length=122)
    l_password = models.CharField(max_length=122)

    def __str__(self):
        return self.l_username



class Product(models.Model):
    name = models.CharField(max_length=1222)

class Detail(models.Model):
        name = models.CharField(max_length=122)
        email = models.CharField(max_length=80)
        mobile = models.CharField(max_length=14)
        address = models.TextField()
        date = models.DateField()

        def __str__(self):
            return self.name

class Item(models.Model):
    name = models.CharField(max_length=122)
    price=models.DecimalField(max_digits=10,decimal_places=4)

    def __str__(self):
        return self.name