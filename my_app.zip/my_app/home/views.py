from django.shortcuts import render, HttpResponse,HttpResponseRedirect
from datetime import datetime
from home.models import Contect
from home.models import Detail
from home.models import Item
from django.contrib import messages
from django.contrib.auth.models import User,auth
from django.contrib.auth import login, logout, authenticate
from django.shortcuts import redirect
from home.models import Product
from home.forms import SearchForm
from django.contrib.auth import login
# Create your views here.
def index(request):
    # context = {
    #     'variable':"guys",
    #     'variable2':"kaise ho"
    # }
    return render(request, 'index.html')
    # return HttpResponse("this is homepage")

def about(request):
    return render(request,'about.html')

def singup(request):
    if request.method == "POST":
        usernaam = request.POST.get('usernaam')
        email = request.POST.get('email')
        password = request.POST.get('password')
        # password1 = request.POST.get('password1')



        user = User.objects.create_user(usernaam,email)

        user.set_password(password)
        user.save()
        messages.success(request, "successfully create account.")
        return redirect('/login')


    return render(request,'singup.html')

def contect(request):
    if request.method == "POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        desc = request.POST.get('desc')
        contact = Contect(name=name, email=email, mobile=mobile, desc=desc, date=datetime.today())
        contact.save()
        messages.success(request, "Your Message has sent!.")
    return render(request,'contect_us.html')


def service(request):
    return render(request,'service.html')

def login(request):
    return render(request,'login.html')

def grocary(request):
    return render(request,'grocary.html')

def gadget(request):
    return render(request,'gadget.html')


def fashion(request):
    return render(request,'fashion.html')

def hardware(request):
    return render(request,'hardware.html')

def beauti(request):
    return render(request,'Beauti.html')

def gernal(request):
    return render(request,'gernal.html')

def user_login(request):
    if request.method == "POST":
        l_username = request.POST.get('l_username')
        l_password = request.POST.get('l_password')

        user = authenticate(username=l_username, password=l_password)

        if user is not None:
            login(request,user)
            messages.success(request, " Successfully Logged In")
            return redirect('home')
        else:
            messages.error(request, "invalid user/pass")

    return render(request,'login.html')

def user_logout(request):
    logout(request)
    messages.success(request,'Successfully Logout')
    return redirect('home')

def search(request):
    if request.method == 'GET':
        form = SearchForm(request.GET)
        if form.is_valid():
            query = form.cleaned_data['query']
            # Perform search against YourModel
            results = Product.objects.filter(name__icontains=query)
            return render(request, 'searchbar.html', {'results': results})
    else:
        form = SearchForm()
    return render(request,'searchbar.html')

def detail(request):
    if request.method=="POST":
        name = request.POST.get('name')
        email = request.POST.get('email')
        mobile = request.POST.get('mobile')
        address = request.POST.get('address')
        detail = Detail(name=name, email=email, mobile=mobile, address=address, date=datetime.today())
        detail.save()
        messages.success(request, "Your order is placed!.")
        return redirect('home')
    return render(request,'order.html')


def query(request):
    query = request.GET.get('query')
    if query:
        items = Item.objects.filter(name__icontains=query) | Item.objects.filter(price__icontains=query)
    else:
        items = Item.objects.all()
    return render(request, 'searchbar.html',{'items':items,'query':query})














