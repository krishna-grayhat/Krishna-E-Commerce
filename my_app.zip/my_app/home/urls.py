from django.contrib import admin
from django.urls import path
from home import views
urlpatterns = [
   path("", views.index, name='home'),
   path("about/", views.about, name='about'),
   path("contect", views.contect, name='contect'),
   path("service",views.service,name="service"),
   path("login",views.user_login,name="login"),
   path("logout", views.user_logout, name="logout"),
   path("singup",views.singup,name="singup"),
   path("grocary",views.grocary,name="grocary"),
   path("fashion",views.fashion,name="fashion"),
   path("gadget",views.gadget,name="gadget"),
   path("hardware",views.hardware,name="hardware"),
   path("beauti",views.beauti,name="beauti"),
   path("gernal",views.gernal,name="gernal"),
   path("search",views.search,name='search'),
   path("detail",views.detail,name='detail'),
   path("search/",views.query,name="query")
]